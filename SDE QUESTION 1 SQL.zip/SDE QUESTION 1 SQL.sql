﻿Select CarMaker, CarModel, Sum(SalePriceinDollar) As TotalSalePrice From [CarSales] Where SaleDate >= DATEADD(month, -1, GETDATE()) Group By CarMaker, CarModel
