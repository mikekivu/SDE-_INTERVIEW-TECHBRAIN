﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using EmployeeManagement;
using System.IO;

namespace EmployeeManagementUnitTest
{
    [TestClass]
    public class EmployeeManagementUnitTest
    {
        [TestMethod]
        public void FileExistanceTestValid()
        {
            Employees employees = new Employees(@"Test Files\ValidSalary.csv");
        }

        [TestMethod]
        [ExpectedException(typeof(FileNotFoundException))]
        public void FileExistanceTestInValid()
        {
            Employees employees = new Employees("ValidSala.csv");
        }

        [TestMethod]
        public void EmployeesSalaryTestValid()
        {
            Employees employees = new Employees(@"Test Files\ValidSalary.csv");
        }

        [ExpectedException(typeof(InvalidOperationException))]
        [TestMethod]
        public void EmployeesSalaryTestInValid()
        {
            Employees employees = new Employees(@"Test Files\InValidSalary.csv");
        }

        [TestMethod]
        public void SingleManagerTestValid()
        {
            Employees employees = new Employees(@"Test Files\ValidSalary.csv");
        }

        [ExpectedException(typeof(Exception))]
        [TestMethod]
        public void SingleManagerTestInValid()
        {
            Employees employees = new Employees(@"Test Files\InValidSingleManager.csv");
        }

        [TestMethod]
        public void SingleCEOTestValid()
        {
            Employees employees = new Employees(@"Test Files\ValidSalary.csv");
        }

        [ExpectedException(typeof(Exception))]
        [TestMethod]
        public void SingleCEOTestInValid()
        {
            Employees employees = new Employees(@"Test Files\InValidCEO.csv");
        }

        [TestMethod]
        public void CircularReferenceTestValid()
        {
            Employees employees = new Employees(@"Test Files\ValidSalary.csv");
        }

        [ExpectedException(typeof(Exception))]
        [TestMethod]
        public void CircularReferenceTestInValid()
        {
            Employees employees = new Employees(@"Test Files\InValidCircularReference.csv");
        }

        [TestMethod]
        public void ManagerIsEmployeeTestValid()
        {
            Employees employees = new Employees(@"Test Files\ValidSalary.csv");
        }

        [ExpectedException(typeof(Exception))]
        [TestMethod]
        public void ManagerIsEmployeeTestInValid()
        {
            Employees employees = new Employees(@"Test Files\InValidManagerIsEmployee.csv");
        }

        [TestMethod]
        public void BudgetTest()
        {
            Employees employees = new Employees(@"Test Files\BudgetFile.csv");
            var budget = employees.GetManagerBudget("Employee1");
            Assert.IsTrue(budget == 1250);
        }
    }
}
