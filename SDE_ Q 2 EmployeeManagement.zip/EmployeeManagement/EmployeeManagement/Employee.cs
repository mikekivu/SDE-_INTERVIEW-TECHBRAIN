﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement
{
    internal class Employee
    {
        public string EmployeeId { get; set; }
        public string ManagerId { get; set; }
        public int Salary { get; set; }

        internal Employee(string employeeId,string managerId,int employeeSalary)
        {
            EmployeeId = employeeId;
            ManagerId = managerId;
            Salary = employeeSalary;
        }
    }
}
