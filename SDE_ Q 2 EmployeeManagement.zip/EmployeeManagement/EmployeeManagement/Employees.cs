﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement
{
    public class Employees
    {
        List<Employee> employees;
        public Employees(string filePath)
        {
            employees = new List<Employee>();
            
            if (File.Exists(filePath))
            {
                bool ceoFound = false;

                var lines = File.ReadAllLines(filePath);
                foreach (var line in lines)
                {
                    var columns = line.Split(',');
                    var salary = 0;

                    if (int.TryParse(columns[2], out salary) == false)
                    {
                        throw new InvalidOperationException("Invalid salary of employee " + columns[0]);
                    }

                    if (employees.Where(e => e.EmployeeId == columns[0]).Count() > 0)
                    {
                        throw new Exception(columns[0] + " reports more than one manager.");
                    }

                    if (columns[1] == "")
                    {
                        if (ceoFound == false)
                        {
                            ceoFound = true;
                        }
                        else
                        {
                            throw new Exception("More than one CEO found.");
                        }
                    }

                    employees.Add(new Employee(columns[0], columns[1], salary));
                }

                foreach (var manager in employees)
                {
                    if (string.IsNullOrWhiteSpace(manager.ManagerId) == false)
                    {
                        if (employees.Where(e => e.EmployeeId == manager.ManagerId).Count() == 0)
                        {
                            throw new Exception(manager.ManagerId + " is not an employee.");
                        } 
                    }

                    if (string.IsNullOrWhiteSpace(manager.ManagerId) == false)
                    {
                        var employee = employees.Where(e=>e.EmployeeId ==  manager.ManagerId).FirstOrDefault();
                        if(employee != null)
                        {
                            if(employee.ManagerId == manager.EmployeeId)
                            {
                                throw new Exception(employee.EmployeeId + " " + employee.ManagerId + "show circular refrence.");
                            }
                        }
                    }
                }
            }
            else
            {
                throw new FileNotFoundException("File does not exist.");
            }
        }

        public long GetManagerBudget(string managerId)
        {
            long budget = 0;
            var manager = employees.Where(e => e.EmployeeId == managerId).FirstOrDefault();
            if(manager != null)
            {
                var emps = employees.Where(e => e.ManagerId == manager.EmployeeId).ToList();
                budget = manager.Salary + GetBudget(emps);
            }
            else
            {
                throw new Exception("Invalid Manager Id.");
            }
            return budget;
        }

        private long GetBudget(List<Employee> emps)
        {
            long budget = 0;
            if(emps.Count() == 0)
            {
                return budget;
            }
            budget = emps.Sum(e => e.Salary);
            var subEmployees = new List<Employee>();
            foreach (var emp in emps)
            {
                var employee = employees.Where(e => e.ManagerId == emp.EmployeeId);
                if(employee.Count() > 0)
                {
                    subEmployees.AddRange(employee);
                }
            }

            return budget + GetBudget(subEmployees);
        }
    }
}
